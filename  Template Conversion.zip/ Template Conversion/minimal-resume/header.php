<div class="container">
    <div class="hero">
        <h1 class="name"><strong>Abbie</strong> Bradley</h1>
        <span class="job-title">Developer</span>
        <span class="email">abbie.bradley@gmail.com</span>

        <h2 class="lead">Development and design of web applications
            for startups and large companies</h2>
    </div>
</div>