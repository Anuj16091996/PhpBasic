<div class="container">

    <div class="sections">
        <h2 class="section-title">Skills</h2>

        <div class="list-card">
            <span class="exp">+ 5 years</span>
            <div>
                <h3>Object programming & frameworks</h3>
                <span>PHP, Symfony, Laravel, Silex, …</span>
            </div>
        </div>

        <div class="list-card">
            <span class="exp">+ 3 years</span>
            <div>
                <h3>Design integration</h3>
                <span>Style and tools, JS Frameworks</span>
            </div>
        </div>

        <div class="list-card">
            <span class="exp">+ 6 years</span>
            <div>
                <h3>Linux</h3>
                <span>Scripting, Servers management and protocols, Automation</span>
            </div>
        </div>


    </div>
    <div class="sections">
        <h2 class="section-title">Interests</h2>

        <div class="list-card">
            <div>
                <h3>Scripting languages</h3>
                <span>PHP, JS, Bash, Python</span>
            </div>
        </div>

        <div class="list-card">
            <div>
                <h3>Hacking</h3>
                <span>Linux, Crawlers, Bots, Network</span>
            </div>
        </div>
    </div>
</div>