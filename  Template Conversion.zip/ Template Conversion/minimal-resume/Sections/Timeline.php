<div class="container">
    <ol class="timeline">
        <li>
            <p class="line">Experiences</p>
            <span class="point"></span>
            <p class="description">
                Lead Developer @Geronimo
            </p>
            <span class="date">Today - Apr. 2016</span>
        </li>

        <li>
            <span class="point"></span>
            <p class="description">
                Freelance
            </p>
            <span class="date">Apr. 2016 - Sep. 2015</span>
        </li>

        <li>
            <p class="line">Education</p>
            <span class="point"></span>
            <p class="description">
                DUT "Métiers du multimédia et de l'internet"
            </p>
            <span class="date">2015 - 2013</span>
        </li>

        <li>
            <span class="point"></span>
            <p class="description">
                Art & Design studies
            </p>
            <span class="date">2013 - 2008</span>
        </li>
    </ol>

</div>
