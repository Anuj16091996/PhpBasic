<footer class="fixed-bottom">
    <div class="container-fluid">
        <p class="float-right">&copy; All rights reserved - 2021</p>
    </div>
</footer>