<!DOCTYPE html>
<html>

<head>
    <?php
    include_once '../include/head.php';
    ?>
</head>

<body>
<?php
include_once 'include/admin-navbar.php';
?>
<div class="container-fluid">
    <p class="page-content">Home administration</p>
</div>

<?php

include_once '../include/footer.php';
?>

</body>

</html>