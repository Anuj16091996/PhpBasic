<!DOCTYPE html>
<html>
<?php
include_once '../include/head.php';
?>
<head>

</head>

<body>
<?php
include_once 'include/admin-navbar.php';
?>

    <div class="container-fluid">
        <p class="page-content">User administration</p>
    </div>
<?php

include_once '../include/footer.php';
?>

</body>

</html>